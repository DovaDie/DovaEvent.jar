package vn.dova.event;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Arrays;

public final class DovaEvent extends JavaPlugin implements Listener {
    private static final String MENU_TITLE = color("&8DovaEvent &7- Quan ly su kien");

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("DovaEvent da bat! Phat trien boi Truongnho_em.");
    }

    @Override
    public void onDisable() {
        getLogger().info("DovaEvent da tat.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("event")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(color("&cLenh nay chi dung trong game."));
                return true;
            }
            if (args.length > 0 && args[0].equalsIgnoreCase("admin")) {
                if (!player.hasPermission("dovaevent.admin")) {
                    player.sendMessage(color("&cBan khong co quyen dung lenh nay."));
                    return true;
                }
                openMenu(player);
                return true;
            }
            openMenu(player);
            return true;
        }

        if (command.getName().equalsIgnoreCase("dova")) {
            if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
                sender.sendMessage(color("&6&lDovaEvent &7- Huong dan"));
                sender.sendMessage(color("&e/event &7- Mo menu su kien"));
                sender.sendMessage(color("&e/event admin &7- Mo menu quan tri (OP)"));
                sender.sendMessage(color("&e/dova event &7- Mo menu su kien"));
                sender.sendMessage(color("&e/dova help &7- Xem huong dan"));
                sender.sendMessage(color("&7Plugin duoc phat trien boi &aTruongnho_em"));
                return true;
            }
            if (args[0].equalsIgnoreCase("event")) {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(color("&cLenh nay chi dung trong game."));
                    return true;
                }
                if (args.length > 1 && args[1].equalsIgnoreCase("admin")
                        && !player.hasPermission("dovaevent.admin")) {
                    player.sendMessage(color("&cBan khong co quyen dung lenh nay."));
                    return true;
                }
                openMenu(player);
                return true;
            }
            sender.sendMessage(color("&cKhong ro lenh. Dung /dova help"));
            return true;
        }
        return false;
    }

    private void openMenu(Player player) {
        Inventory inventory = Bukkit.createInventory(null, 27, MENU_TITLE);
        ItemStack filler = item(Material.GRAY_STAINED_GLASS_PANE, "&7 ");
        for (int slot = 0; slot < inventory.getSize(); slot++) inventory.setItem(slot, filler);

        inventory.setItem(11, item(Material.CHEST, "&a&lTao su kien",
                "&7Nhan de tao mot su kien moi.",
                "&eTrang thai: &cChua co su kien"));
        inventory.setItem(13, item(Material.BOOK, "&b&lThong tin DovaEvent",
                "&7Quan ly su kien trong menu.",
                "&7Phat trien boi: &aTruongnho_em"));
        inventory.setItem(15, item(Material.BARRIER, "&c&lDong menu",
                "&7Nhan de dong giao dien."));
        player.openInventory(inventory);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!MENU_TITLE.equals(event.getView().getTitle())) return;
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) return;
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || !clicked.hasItemMeta() || !clicked.getItemMeta().hasDisplayName()) return;
        String name = clicked.getItemMeta().getDisplayName();
        if (name.equals(color("&c&lDong menu"))) {
            player.closeInventory();
        } else if (name.equals(color("&a&lTao su kien"))) {
            player.sendMessage(color("&e[DovaEvent] &fChuc nang tao va khoi dong su kien se duoc cau hinh tiep."));
            player.sendMessage(color("&7Hien tai menu mau da hoat dong; chua co he thong phat su kien thuc te."));
            player.closeInventory();
        }
    }

    private ItemStack item(Material material, String name, String... lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(color(name));
            if (lore.length > 0) {
                meta.setLore(Arrays.stream(lore).map(DovaEvent::color).toList());
            }
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private static String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text);
    }
}
